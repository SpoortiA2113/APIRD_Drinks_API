from django.shortcuts import render
from django.http import HttpResponse
from .models import Drink
from .serializers import DrinkSerializer   
from rest_framework.decorators import api_view
from rest_framework.response import Response

# Create your views here.
# function based view
# class based view

# templates/appname/filename.html
def home(request):
    return render(request, 'Drinks/index.html',context={})

# implementation of api endpoints   
# 
# get method -> get all the drinks


# Request: A user sends a GET request.
# Urls.py -> views.py -> models.py -> serializers.py -> views.py -> Response
# View: The TaskViewSet fetches all tasks from the database.

# Serializer: The TaskSerializer converts those database objects into JSON.
 
# Response: The API returns the JSON data to the user.

# decorators -> @api_view, @permission_classes, @authentication_classes

@api_view(['GET','POST'])
def get_post_drinks(request):
    if request.method == 'GET':
        drinks = Drink.objects.all() # [obj1,obj2,obj3]
        drinkserializer = DrinkSerializer(drinks,many=True) # [obj1,obj2,obj3] -> [{name: ,price: ,des: ,q:},{},{}]
        return  Response(drinkserializer.data)
    elif request.method == 'POST':
        data = request.data # {name: ,price: ,des: ,q:}
        drinkserializer = DrinkSerializer(data=data) # {name: ,price: ,des: ,q:} -> obj
        if drinkserializer.is_valid():
            drinkserializer.save()
            return Response(drinkserializer.data, status=201)
        return Response(drinkserializer.errors, status=400)
        



# get specific drink -> get method -> /getdrink/1/ -> id = 1 -> get the drink with id 1 from db -> serialize it -> return response        



# get,put,delete 
@api_view(['GET','PUT','DELETE'])
def get_put_delete_drink(request, id):
    try:
        drink = Drink.objects.get(id=id) # obj11  
    except Drink.DoesNotExist:
        return Response(status=404)
    if request.method == 'GET':
        drinkserializer = DrinkSerializer(drink) # obj1 -> {name: ,price: ,des: ,q:}
        return  Response(drinkserializer.data)  
    elif request.method == 'PUT':
        datac=request.data  # {name: ,price: ,des: ,q:}
        drinkserializer = DrinkSerializer(drink,datac) # {name: ,price: ,des: ,q:} -> obj
        if drinkserializer.is_valid():
            drinkserializer.save()
            return Response(drinkserializer.data, status=201)
        return Response(drinkserializer.errors, status=400)
    elif request.method == 'DELETE':
        drink.delete()# delete the drink with id 1 from db
        return Response("drink deleted", status=204)